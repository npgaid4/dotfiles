//
//  Utils.h
//  TestUtils
//
//  Created by iOS Developer on 2021/06/29.
//

#ifndef Utils_h
#define Utils_h

@interface Utils : NSObject

- (NSData *)getDataWithHexString:(NSString *)str;
- (NSData *)getNSDataWithHexString:(NSString *)str;
- (BOOL)validationInputString:(NSString*)input;

@end



#endif /* Utils_h */
