//
//  ViewController.h
//  TestUtils
//
//  Created by iOS Developer on 2021/06/29.
//

#import <Cocoa/Cocoa.h>
#import "Utils.h"

@interface ViewController : NSViewController

@property (weak) IBOutlet NSTextField *inputTxt;
@property (weak) IBOutlet NSButton *assertBtn;
@property (weak) IBOutlet NSTextField *resultLabel;

@property (nonatomic) Utils *utils;

@end

