//
//  Utils.m
//  TestUtils
//
//  Created by iOS Developer on 2021/06/29.
//

#import <Foundation/Foundation.h>
#import "Utils.h"

@implementation Utils

- (NSData *)getNSDataWithHexString:(NSString *)str {
    NSMutableData *output = [[NSMutableData alloc] init];
    
    return output;
}

- (NSData *)getDataWithHexString:(NSString *)str {
    
    NSMutableData *hexData = [[NSMutableData alloc] init];
    NSRange range = NSMakeRange(0, 2);
    for (NSInteger i = range.location; i < [str length]; i += 2) {
        unsigned int anInt;
        NSString *hexCharStr = [str substringWithRange:range];
        NSScanner *scanner = [[NSScanner alloc] initWithString:hexCharStr];
        [scanner scanHexInt:&anInt];
        NSData *entity = [[NSData alloc] initWithBytes:&anInt length:1];
        [hexData appendData:entity];
        range.location += range.length;
        range.length = 2;
    }
    return hexData;
}

-(BOOL)validationInputString:(NSString*)input {
    NSString *pattern = @"[^0-9A-Fa-f]";

    if([input rangeOfString:pattern options: NSRegularExpressionSearch].location != NSNotFound){
        return NO;
    }else{
        return YES;
    }
}
@end
