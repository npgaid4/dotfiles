//
//  AppDelegate.h
//  TestUtils
//
//  Created by iOS Developer on 2021/06/29.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

