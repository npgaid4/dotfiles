//
//  ViewController.m
//  TestUtils
//
//  Created by iOS Developer on 2021/06/29.
//

#import "ViewController.h"

@implementation ViewController


- (void)viewDidLoad {
    [super viewDidLoad];

    // Do any additional setup after loading the view.
    self.utils = [[Utils alloc]init];
    printf("Utils create");
}


- (void)setRepresentedObject:(id)representedObject {
    [super setRepresentedObject:representedObject];

    // Update the view, if already loaded.
}

- (IBAction)assertDoing:(id)sender {
    BOOL isMojiCheck = YES;
    NSString *str = self.inputTxt.stringValue;
    NSString *errorStr = @"";
    
    if (str.length == 0) {
        isMojiCheck = NO;
        errorStr = @"空文字です";
    }
    
    NSString *inputNoSpace = [str stringByReplacingOccurrencesOfString:@"\\s" withString:@"" options:NSRegularExpressionSearch range:NSMakeRange(0, [str length])];

    //奇数文字長はだめなので。先頭に0を追加。いいのか？
    if((inputNoSpace.length % 2) == 1){
        inputNoSpace = [@"0" stringByAppendingString:inputNoSpace];
    }
    
    BOOL isValidateCheck = [self.utils validationInputString:inputNoSpace];

    if(!isValidateCheck){
        errorStr = @"16進数以外の文字があります";
    }
    
    NSLog(@"INPUT文字列: %@",inputNoSpace);

    if(isMojiCheck && isValidateCheck){
        NSData *data1 = [self.utils getDataWithHexString:inputNoSpace];
        NSData *data2 = [self.utils getNSDataWithHexString:inputNoSpace];
        
        BOOL result = [data1 isEqualToData:data2];
        if(result){
            [self.resultLabel setStringValue:@"True"];
        }else{
            [self.resultLabel setStringValue:@"False"];
        }
    }else{
        [self.resultLabel setStringValue:errorStr];
    }
}


@end
